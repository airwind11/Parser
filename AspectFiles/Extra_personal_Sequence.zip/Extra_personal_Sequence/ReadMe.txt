1. Run the Batch Script
2. Provide the path to the test file folder that contains the JAVA file  (ex - C:\Users\aravi\OneDrive\Documents\ACADS\202-SW_systems_Engr\PersonalProjectTest\test1)
3. Provide the path where the output Sequence Diagram will be stored.
4. seq.png is the final Sequence diagram in the output path.

